import sys
from socket import *
import time

def pinger():

    DEFAULT_PORT = 1337
    DEFAULT_SIZE = 100
    DEFAULT_COUNT = 10
    DEFAULT_TIMEOUT = 1000

    params_by_flag_dict = {"-p": DEFAULT_PORT,
                           "-s": DEFAULT_SIZE,
                           "-c": DEFAULT_COUNT,
                           "-t": DEFAULT_TIMEOUT}
    
    num_params = len(sys.argv)
    error_message = "Error: Arguments not provided in correct format"

    # Check if number of args provided is valid
    if 2 <= num_params <= 10 and num_params % 2 == 0:
        ip = sys.argv[1]

        # Update flags dictionary according to provided args
        for i in range(2, num_params, 2):
            if sys.argv[i] in params_by_flag_dict.keys() and sys.argv[i + 1].isnumeric():
                params_by_flag_dict[sys.argv[i]] = int(sys.argv[i + 1])
            else:
                handle_error(error_message)
                
        port = params_by_flag_dict["-p"]
        size = params_by_flag_dict["-s"]
        count = params_by_flag_dict["-c"]
        timeout = params_by_flag_dict["-t"]

        if count <= 0:
            handle_error(error_message)

        init_pinger(ip, port, size, count, timeout)
              
    # Number of args provided is incorrect. Print error.    
    else:
        handle_error(error_message)


def handle_error(error_message):
    print(error_message)
    sys.exit(1)

def calc_rtt(start_time, end_time):
    return round((end_time - start_time) * 1000, 3)

def init_pinger(ip, port, size, count, timeout):
    received_packets = 0

    with socket(AF_INET, SOCK_DGRAM) as pinger_socket:
        agent_address = (ip, port)
        pinger_socket.settimeout(timeout / 1000)
        for seq in range(count):
            try: 

                # Construct pinger message
                pinger_message = construct_pinger_message(size, seq)

                # Send and receive message from agent
                start_time = time.time()
                pinger_socket.sendto(pinger_message, agent_address)

                # Loop handles previously sent packets that have been received in delay 
                while True:
                    data, agent = pinger_socket.recvfrom(len(pinger_message))
                    end_time = time.time()

                    # Check if seq number doesn't match the expected seq or timeout exceeded
                    if int.from_bytes(data[1:5], 'big') == seq or calc_rtt(start_time, end_time) >= timeout:
                        break

                # Print packet transmittion stats if rtt is smaller than timeout
                print_packet_transmittion_stats(agent[0], data, seq, start_time, end_time, timeout)
                received_packets += 1

            # Timeout exceeded
            except:
                print(f'request timeout for icmp_seq {seq}')

        # Print final statistics of ping session
        trans_recv_ratio = round((1 - (received_packets / count)) * 100, 2)
        print(f'--- {ip} statistics ---')
        print(f'{count} packets transmitted, {received_packets} packets received, {trans_recv_ratio}% packet loss')
        
        
def print_packet_transmittion_stats(agent_ip, data, seq, start_time, end_time, timeout):
    rtt = calc_rtt(start_time, end_time)
    if rtt >= timeout:
        raise
    len_data = len(data)
    print(f"{len_data} bytes from {agent_ip}: seq={seq} rtt={rtt} ms")

def construct_pinger_message(size, seq):
     opcode = b'0'
     data = ('a' * size).encode()
     return opcode + seq.to_bytes(4, 'big') + data
     

if __name__ == "__main__":
    pinger()