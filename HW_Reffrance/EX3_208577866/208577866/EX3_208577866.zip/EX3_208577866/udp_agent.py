import sys
from socket import *

def agent():
    DEFAULT_PORT = 1337
    num_params = len(sys.argv)

    # Check if port provided
    if num_params == 3 and sys.argv[1] == '-p' and sys.argv[2].isnumeric():
        port = int(sys.argv[2])
        init_agent(port)

    # Check if no args provided
    elif num_params == 1:
        init_agent(DEFAULT_PORT)

    # Number of args provided is incorrect. Print error.    
    else:
        sys.exit(1)


def init_agent(port):
    MAX_MESSAGE_SIZE = 1405

    with socket(AF_INET, SOCK_DGRAM) as agent_socket:
        host = "127.0.0.1"
        agent_socket.bind((host, port))
        while True:
            data, pinger_address = agent_socket.recvfrom(MAX_MESSAGE_SIZE)
            agent_message = b'1' + data[1:]
            agent_socket.sendto(agent_message, pinger_address)

if __name__ == "__main__":
    agent()